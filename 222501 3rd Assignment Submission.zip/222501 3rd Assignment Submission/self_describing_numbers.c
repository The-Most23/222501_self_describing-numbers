#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int getNoOfElements(int testCase, char* element){
  int counter = 0;
  for (int i = 0; i < strlen(element); i++){
    char currentChar = element[i] - '0';
    if (testCase == currentChar){
      counter++;
    }

  }
  return counter;
}


int checkSelfDescribe(char *inputs){
  int result = 0;
  for (int i = 0 ; i < strlen(inputs); i++){
    int currentChar = inputs[i] - '0'; //coverting the input from a char to an integer
    int noOfElements = getNoOfElements(i, inputs);
    if (currentChar == noOfElements){
      result = 1;
    } else{
      result = 0;
      break;
    }
  }

  return result;
}


int main(){

    

    FILE *fpointer = fopen("Adam.in","r");//opening the file 
    int test;
    fscanf(fpointer,"%d",&test);

    for (int i = 0 ; i < test; i++){
        char inputs[100];
        int lenght;
        
        //Reading the input in every line of the file
        fscanf(fpointer,"%s",inputs);
        lenght = strlen(inputs);

        int result = checkSelfDescribe(inputs);

        if (result == 1){
          printf("\n %s is a self describing number", inputs);
        } else{
          printf("\n %s is not a self describing number", inputs);
        }

        }
              
    fclose(fpointer);
    return 0;

}