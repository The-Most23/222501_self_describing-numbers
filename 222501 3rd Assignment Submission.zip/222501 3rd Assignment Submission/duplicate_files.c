#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){

 FILE *fpointer = fopen("files.in","r");//opening the file 
    int test;
    
    fscanf(fpointer,"%d",&test);

    for (int i = 0 ; i < test; i++){
        int no_of_file1;
        //checking for the number of files which are ddddupllicates and thise that are not duplicates
        fscanf(fpointer,"%d",&no_of_file1); 
        //printf("%d\n",no_of_file1);
        //looping throuhg the number of files in each test cases
        for (int j = 0 ; j < no_of_file1; j++){
            char filenames[100];
            int i,j;
            fscanf(fpointer,"%s",filenames);
            //printf("%s\n",filenames);
            
            
            for(i = 0; filenames[i] != '\0'; i++){
                if(filenames[i] == '0' || filenames[i] == '1' || filenames[i] == '2' || filenames[i] == '3' || filenames[i] == '4' || filenames[i] == '5' || filenames[i] == '6' || filenames[i] == '7' || filenames[i] == '8' || filenames[i] == '9')
                {
                    for(j = i; filenames[j] != '\0'; j++){
                        filenames[j] = filenames[j + 1];
                        // getting the ID and lenght of the files input
                    int l_of_filename;
                    l_of_filename = strlen(filenames);
                    
                    //printf("%d\n",l_of_filename); 
                    }
                }
            }
                printf("%s\n", filenames);

              
              break;   
        }

        int no_of_file2;
        //checking for the number of files which are ddddupllicates and thise that are not duplicates
        fscanf(fpointer,"%d",&no_of_file2); 
        //printf("%d\n",no_of_file1);
        //looping throuhg the number of files in each test cases
        for (int j = 0 ; j < no_of_file2; j++){
            char filenames[100];
            int i,j;
            fscanf(fpointer,"%s",filenames);
            //printf("%s\n",filenames);
            
            
            for(i = 0; filenames[i] != '\0'; i++){
                if(filenames[i] == '0' || filenames[i] == '1' || filenames[i] == '2' || filenames[i] == '3' || filenames[i] == '4' || filenames[i] == '5' || filenames[i] == '6' || filenames[i] == '7' || filenames[i] == '8' || filenames[i] == '9')
                {
                    for(j = i; filenames[j] != '\0'; j++){
                        filenames[j] = filenames[j + 1];
                        // getting the ID and lenght of the files input
                    int l_of_filename;
                    l_of_filename = strlen(filenames);
                    
                    //printf("%d\n",l_of_filename); 
                    }
                }
            }
                printf("%s\n", filenames);

              
              break;   

        
           

        }

        
    }  

    fclose(fpointer);
    return 0;

}




    